"""
1. Perform the following operations using Python on the Facebook metrics data sets
    a. Create data subsets
    b. Merge Data
    c. Sort Data
    d. Transposing Data
    e. Shape and reshape Data
"""

import pandas as pd;
df = pd.read_csv('dataset_Facebook.csv',delimiter=';');
## df
ds = df.describe();
## ds


# [A] Create Data Subsets
# First subset: Like and Share
df_subset_1 = df[['like','share']];
## df_subset_1

# second subset: Comment and Type
df_subset_2 = df[['comment','Type']]
## df_subset_2


# [B] Merge Data
merged_data  = pd.merge(df_subset_2, df_subset_1, left_on='comment', right_on= 'like')
## merged_data


# [C] Sort Data
# Sorting merged_data in descending order wrt 'Like'
sort = merged_data.sort_values(by=['like'],ascending=False);
## sort

# [D] Transposing Data
# Method 1
trans1 = merged_data.transpose();
## trans1

# Method 2
trans2 = merged_data.T;
## trans2


# [E] Shape And Reshape Data
## df

# Shape
print(df.shape);


# Reshape
reshape = pd.melt(df, id_vars =['Type'], value_vars =['comment']);
## reshape


# # Sort the DataFrame by 'type' and 'variable'
# reshaped_df.sort_values(by=['type', 'variable'], inplace=True)

# # Reset the index
# reshaped_df.reset_index(drop=True, inplace=True)