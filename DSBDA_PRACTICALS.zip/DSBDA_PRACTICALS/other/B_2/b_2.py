
"""
Perform the following operations using Python on the Air quality and Heart Diseases data sets
    a. Data cleaning
    b. Data integration
    c. Data transformation
    d. Error correcting
    e. Data model building
"""

import pandas as pd
import numpy as np
df = pd.read_csv('airquality_data.csv', encoding='cp1252');
head = df.head();
## head

info = df.info();
## info

cols = df.columns;
## cols

# [A] Data Cleaning
# Change data type from float64 to float32 for Space Complexity
df['so2'] = df['so2'].astype('float32');
df['no2'] = df['no2'].astype('float32');
df['rspm'] = df['rspm'].astype('float32');
df['spm'] = df['spm'].astype('float32');
df['date'] = df['date'].astype('string');

info = df.info();

df=df.drop_duplicates();

sum = df.isna().sum();

percent_missing = df.isnull().sum() * 100 / len(df);

percent_missing_sorted = percent_missing.sort_values(ascending=False);

df=df.drop(['stn_code', 'agency','sampling_date','location_monitoring_station','pm2_5'], axis = 1)

head = df.head();

cols = df.columns;

col_var = ['state', 'location', 'type','date']
col_num = ['so2','no2','rspm','spm']
for col in df.columns:
    if df[col].dtype == 'object' or df[col].dtype == 'string':
        df[col] = df[col].fillna(df[col].mode()[0])
    else:
        df[col] = df[col].fillna(df[col].mean())
sum = df.isna().sum();

## df


sum = df.isna().sum();  