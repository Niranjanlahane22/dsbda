import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# treat nan missing values as nan
cars_data=pd.read_csv('Toyota.csv',index_col=0,na_values=['??','????'])
cars_data1=cars_data.copy(deep=True)
cars_data.shape
cars_data.info()
cars_data.isnull().sum()

# removing nan valuse
cars_data.dropna(axis=0,inplace=True)
cars_data.size
cars_data.shape

## --------------------Data Visualization using matplotlib Library -------------------

## SCATTER PLOT
plt.scatter(cars_data['Age'],cars_data['Price'],c='blue')
plt.title("Scatter Plot Car Price vs Age")
plt.xlabel('Agee in months')
plt.ylabel('Price in Dollars')


##  HISTOGRAM
plt.hist(cars_data["KM"])
# histogram with default arguments
plt.hist(cars_data['KM'],color='blue', edgecolor='white',bins=5)
plt.hist(cars_data['KM'],color='blue', edgecolor='white',bins=8)
  # bins specify the count of distribution range
plt.title("Histogram of Kilometer run")
plt.xlabel('Kelometers')
plt.ylabel('Frequency')
plt.show()
'''
plt. show() starts an event loop, looks for all currently active figure objects, 
and opens one or more interactive windows that display your figure or figures.
'''
## BAR PLOT

# Seting attribute counts, fuelTypes and index based on Dataset
cars_data['FuelType'].value_counts() # get count of categorical variable 
counts=cars_data['FuelType'].value_counts()
fuelTypes=('Petrol', 'Disel','CNG')
index=np.arange(len(fuelTypes))
#counts=[50,100,75]

plt.bar(index,counts,color=['red','green','cyan'])

plt.title("Bar Plot of Fuel Type")
plt.xlabel('Fuel Used')
plt.ylabel('Frequency')

# Bar label
#plt.xticks(index,fuelTypes)
plt.xticks(index,fuelTypes,rotation=90)
plt.show()


## ---------------------------------------------------------------------------
## ---- Data Visualization using seaborn library -------------------

# [A] SCATTER PLOT using seaborn regplot()
sns.set(style='darkgrid')
sns.regplot(x=cars_data['Age'],y=cars_data['Price']) #FIGURE
plt.show()

##-------[B] HISTOGRAM using seaborn distplot() ----------------
# Histogram with default kernel density estimate
sns.distplot(cars_data['Age'])
plt.show()

# Histogram with specified number of bins
sns.distplot(cars_data['KM'], bins=10)
plt.show()

# [C] Histogram without kernel density estimate
sns.distplot(cars_data['Age'], kde=False)
plt.show()

## --------[D] BAR PLOT using seaborn countplot()
sns.countplot(x='FuelType', data=cars_data)
plt.show()

# Grouped bar plot of FuelType and Automatic
sns.countplot(x='FuelType', data=cars_data, hue='Automatic')
plt.show()

##---------[E] BOX PLOT using seaborn boxplot()-----
sns.boxplot(y=cars_data['Price'])
plt.show()

# Box plot for numerical data vs categorical data
sns.boxplot(y=cars_data['Price'], x=cars_data['FuelType'])
plt.show()