import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# treat missing values as nan
cars_data=pd.read_csv('Toyota.csv',index_col=0,na_values=['??','????'])
cars_data1=cars_data.copy(deep=True)
cars_data.shape
cars_data.info()
cars_data.isnull().sum()
# removing nan valuse
cars_data.dropna(axis=0,inplace=True)
cars_data.size
cars_data.shape

## --------------------Data Visualization using matplotlib Library -------------------

## [A] SCATTER PLOT
plt.scatter(cars_data['Age'],cars_data['Price'],c='red')
plt.title("Scatter Plot Car Price vs Age")
plt.xlabel('Age in months')
plt.ylabel('Price in Dollars')
plt.show()

## [B] HISTOGRAM
plt.hist(cars_data["KM"])
# histogram with default arguments
plt.hist(cars_data['KM'],color='blue', edgecolor='white',bins=5)
plt.hist(cars_data['KM'],color='red', edgecolor='white',bins=8)
# bins specify the count of distribution range
plt.title("Histogram of Kilometer run")
plt.xlabel('Kelometers')
plt.ylabel('Frequency')
plt.show()

## [C] BAR PLOT
# Seting attribute counts, fuelTypes and index based on Dataset
cars_data['FuelType'].value_counts() # get count of categorical variable 
counts=cars_data['FuelType'].value_counts()
fuelTypes=('Petrol', 'Disel','CNG')
index=np.arange(len(fuelTypes))
#counts=[50,100,75]
plt.bar(index,counts,color=['red','green','cyan'])
plt.title("Bar Plot of Fuel Type")
plt.xlabel('Fuel Used')
plt.ylabel('Frequency')
# Bar label
plt.xticks(index,fuelTypes,rotation=90)
plt.show()

## ---- Data Visualization using seaborn library -------------------
# [A] SCATTER PLOT using seaborn regplot()
sns.set(style='darkgrid')
sns.regplot(x=cars_data['Age'],y=cars_data['Price']) #FIGURE
plt.show()

## [B] HISTOGRAM using seaborn distplot() 
# (a)Histogram with default kernel density estimate
sns.distplot(cars_data['Age'])
plt.show()

# (b)Histogram without kernel density estimate
sns.distplot(cars_data['Age'], kde=False)
plt.show()

## [C] BAR PLOT using seaborn countplot()
sns.countplot(x='FuelType', data=cars_data)
plt.show()