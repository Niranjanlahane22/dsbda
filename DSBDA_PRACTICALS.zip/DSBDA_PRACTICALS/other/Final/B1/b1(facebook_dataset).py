import pandas as pd
df = pd.read_csv('fb.csv');
ds = df.describe(); ##ds

# CREATING DATA SUBSET
df_subset1 = df[['like','share']]; ##df_subset1
df_subset2 = df[['comment','type']];##df_subset2

merged_subset = pd.merge(df_subset2,df_subset1,left_on='comment',right_on='like'); ##merged_subset


sorted_data = merged_subset.sort_values(by=['like'], ascending=False); ##sorted_data

transposed_data = sorted_data.transpose(); ##transposed_data

# print(df);

print(df.shape)

reshaped_df = pd.melt(df,id_vars='type',value_vars=['comment','likes']);  ##reshaped_df
