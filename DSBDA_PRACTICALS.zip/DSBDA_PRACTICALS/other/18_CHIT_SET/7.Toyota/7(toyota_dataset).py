"""
7. Perform the following operations using Python on the given data sets
(Toyota.csv)
    a. Remove all missing values
    b. display datatypes and concise summary of all numeric variables
    c. Remove All duplicate records
    d. Apply Z-score Normalization on Price Column
    e. shape and reshape using pivot_ table

"""
import pandas as pd
df = pd.read_csv('Toyota.csv')

# -------------------------------[A]Remove all missing values---------------------------------
# df.dropna(inplace=True)


#check count of missing values present in each column 
df.isnull().sum()
# replacing nan values for numeric variables by mean / median of that variable
df['Age'].fillna(df['Age'].mean(),inplace=True)
df['HP'].fillna(df['HP'].mean(),inplace=True)
df['KM'].fillna(df['KM'].median(),inplace=True)
null_sum = df.isnull().sum()


# replacing nan values for categorcal variables 
df['FuelType'].value_counts()
df['FuelType'].fillna(df['FuelType'].value_counts().index[0],inplace=True)
df['MetColor'].fillna(df['MetColor'].value_counts().index[0],inplace=True)
df.isnull().sum()

# -------------------------------[B]display datatypes and concise summary of all numeric variables---------------------------------
#display datatypes
datatypes = df.dtypes          

#concise summary of all numeric variables
des = df.describe()        

# -------------------------------[C]Remove All duplicate records---------------------------------
df1=df.drop_duplicates(inplace=True)

# -------------------------------[D]Apply Z-score Normalization on Price Column---------------------------------
def ZScore_normalize(x):
    return (x - x.mean()) / x.std()

ZScore_normalize(df['Price'])
df['Price'] =ZScore_normalize(df['Price'])

# -------------------------------[E]shape and reshape using pivot_ table---------------------------------
print("Shape of the dataset:", df.shape)

pivot_table = pd.pivot_table(df, index='Age', values='Price', aggfunc='mean')
print(pivot_table)