"""
8. Visualize the data using Python libraries matplotlib / seaborn
    1. Scatter plot- Car-Price by Age
    2. Histogram on Cars data KM
    3. Bar plot on counts of FuelType category (Petrol, Disel and CNG)

"""
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np


# treat nan missing values as nan
df=pd.read_csv('Toyota.csv',index_col=0,na_values=['??','????'])
df1=df.copy(deep=True)
df.shape
df.info()
df.isnull().sum()
# removing nan valuse
df.dropna(axis=0,inplace=True)
df.size
df.shape

# ----------------------------------------------------------------------------------------------

# 1. Scatter plot- Car-Price by Age
plt.scatter(df['Age'],df['Price'],c='blue')
plt.title("Scatter Plot Car Price vs Age")
plt.xlabel('Agee in months')
plt.ylabel('Price in Dollars')
plt.show()

# 2. Histogram on Cars data KM

plt.hist(df["KM"])
# histogram with default arguments
plt.hist(df['KM'],color='blue', edgecolor='white',bins=5)
plt.hist(df['KM'],color='blue', edgecolor='white',bins=8)
 # bins specify the count of distribution range
plt.title("Histogram of Kilometer run")
plt.xlabel('Kelometers')
plt.ylabel('Frequency')
plt.show()

# 3. Bar plot on counts of FuelType category (Petrol, Disel and CNG)

df['FuelType'].value_counts() # get count of categorical variable 
counts=df['FuelType'].value_counts()
fuelTypes=('Petrol', 'Disel','CNG')
index=np.arange(len(fuelTypes))
#counts=[50,100,75]
plt.bar(index,counts,color=['red','green','cyan'])
plt.title("Bar Plot of Fuel Type")
plt.xlabel('Fuel Used')
plt.ylabel('Frequency')